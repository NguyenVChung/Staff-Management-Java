import java.util.ArrayList;
import java.util.List;

public class CreateFunction{

    private List<NhanVien> nvs;

    public CreateFunction() {
        nvs = new ArrayList<NhanVien>();
    }

    public void input() {
        NhanVien nv = new NhanVien();
        nv.input();
        nvs.add(nv);
    }

    public void output() {
        for (NhanVien nv : nvs) {
            nv.output();
        }
    }
    
    

    //search method
    public boolean searchByFullName(String search) {
        boolean check = false;
        for (NhanVien nv : nvs) {
            if (nv.getnames().toLowerCase().equals(search)) {
                check = true;
                
            }
        }

        return check;
    }
	

	public boolean searchByDepartment(String search) {
        boolean check = false;
        for (NhanVien nv : nvs) {
            if (nv.getphongBan().toLowerCase().equals(search)) {
                nv.output();
                check = true;
            }
        }

        return check;
    }

}
