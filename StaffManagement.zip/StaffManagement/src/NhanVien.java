import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class NhanVien extends CanBo{

	public NhanVien() {
		// TODO Auto-generated constructor stub
	}

	private String phongBan;
	
	private int ngayCong;
	
	public void input(){
		super.input();
		sc.nextLine();
		System.out.print("Phong Ban: ");
		phongBan = sc.nextLine();
		System.out.print("So Ngay Cong: ");
		ngayCong = sc.nextInt();
		
	}
	
	int getsalary(){
		int salary = getheso() * 730 + getphuCap() + ngayCong * 30;
		return salary;
	}
	
	public void output(){
		super.output();
		System.out.println("Phong Ban: " + phongBan);
		System.out.println("Ngay Cong : " +  ngayCong);
		System.out.println("Luong: " + getsalary());
		
		//write into file
		BufferedWriter out = null;
		try  
		{
		    FileWriter fstream = new FileWriter("myfile.txt", true); 
		    out = new BufferedWriter(fstream);
		    out.append("Ho ten: " + names);
		    out.append("\n");
		    out.append("Levels: " + trinhDo);
		    out.append("\n");
		    out.append("Phu Cap: " + phuCap);
		    out.append("\n");
		    out.append("Phong Ban: " + phongBan);
		    out.append("\n");
		    out.append("Ngay Cong : " +  ngayCong);
		    out.append("\n");
		    out.append("Luong: " + getsalary());
		    out.append("\n");
		}
		catch (IOException e)
		{
		    System.err.println("Error: " + e.getMessage());
		}
		finally
		{
		    if(out != null) {
		        try {
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    }
		}
	}
	public String getphongBan(){
		return phongBan;
		
	}
	public void setphongBan(String phongBan){
		this.phongBan = phongBan;
	}
	
	public int getngayCong(){
		return ngayCong;
	}
	public void setngayCong(int ngayCong){
		this.ngayCong = ngayCong;
	}

	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
