import java.util.ArrayList;
import java.util.List;

public class Function2 {

	private List<GiangVien> gvs;
	public Function2() {
		// TODO Auto-generated constructor stub
		gvs = new ArrayList<GiangVien>();
	}

	public void input() {
        GiangVien gv = new GiangVien();
        gv.input();
        gvs.add(gv);
    }

    public void output() {
        for (GiangVien gv : gvs) {
            gv.output();
        }
    }
    
}

   