

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public abstract class CanBo{

	public CanBo() {
		// TODO Auto-generated constructor stub
		// trinh do
	}

	List<String> levels = (List<String>) Arrays.asList("tien si", "thac si", "cu nhan", "truong phong", "pho phong", "nhan vien");
	//Ho ten
	String names;
	//trinh do
	String trinhDo;
	//phu cap
	int phuCap;
	//he so luong
	int heSoLuong;
	
	Scanner sc = new Scanner(System.in);
	public void input(){
		
		System.out.print("Fullname: ");
		sc = new Scanner(System.in);
		names = sc.nextLine();
		
		System.out.print("Levels: ");
		sc = new Scanner(System.in);
		trinhDo = sc.nextLine();
		
		System.out.print("He So Luong: ");
		heSoLuong = sc.nextInt();
		
	}
	
	public void output(){
		System.out.println("Ho ten: " + names);
		System.out.println("Levels: " + trinhDo);
		System.out.println("He So Luong: " + heSoLuong);
		if(trinhDo.toLowerCase().equals(levels.get(0))){
			phuCap = 1000;
			System.out.println("Phu Cap: " + phuCap);
		}else if(trinhDo.toLowerCase().equals(levels.get(1))){
			phuCap = 500;
			System.out.println("Phu Cap: " + phuCap);
		}else if(trinhDo.toLowerCase().equals(levels.get(2))){
			phuCap = 300;
			System.out.println("Phu Cap: " + phuCap);
		}else if(trinhDo.toLowerCase().equals(levels.get(3))){
			phuCap = 2000;
		}else if(trinhDo.toLowerCase().equals(levels.get(4))){
			phuCap = 1000;
			System.out.println("Phu Cap: " + phuCap);
		}else if(trinhDo.toLowerCase().equals(levels.get(5))){
			phuCap = 500;
			System.out.println("Phu Cap: " + phuCap);
		}
	}
	

	abstract int getsalary();
	
	public String getnames(){
		return names;
	}
	
	public void setnames(String names){
		this.names = names;
	}
	
	public String getlevels(){
		return trinhDo;
	}
	
	public void setlevel(String trinhDo){
		this.trinhDo = trinhDo;
	}
	
	public int getheso(){
		return heSoLuong;
	}
	public void setheso(int heSoLuong){
		this.heSoLuong = heSoLuong;
	}
	
	public int getphuCap(){
		return phuCap;
		
	}
	public void setphuCap(int phuCap){
		this.phuCap = phuCap;
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
