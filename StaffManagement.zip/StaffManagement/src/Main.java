
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {

    private static Scanner sc;

	/**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    	
        CreateFunction CreateFunction = new CreateFunction();
        Function2  Function2 = new Function2();
        int menu = 0;
        
        //Create file txt here
        try{
            File file = new File("myfile.txt");
        	if(!file.exists()){
        		file.createNewFile();
        	}
        	PrintWriter pw = new PrintWriter(file);
        	pw.println("How to write file in this situation?");
        	pw.close();
        }catch(IOException e){
        	e.printStackTrace();
        }
        
        //main calling method here
        do {
			do {
                try {
                    System.out.println("--------menu--------");
                    System.out.println("0. Exit");
                    System.out.println("1. Nhap Lieu - nhap doi tuong nhan vien truoc, giang vien sau");
                    System.out.println("2. Tim Kiem Ten");
                    System.out.println("3. Tim kiem Nhan Vien Theo Khoa");
                    System.out.println("4. Sap xep va In ra ket qua");
                    System.out.println("5. Quay lai menu");
                    System.out.print("Hay Chon: ");

                    Scanner sc = new Scanner(System.in);
                    menu = sc.nextInt();
                    break;
                } catch (Exception e) {
                    System.out.println("Please choose menu [1,2,3,4]");
                }
            } while (true);

            switch (menu) {
                case 0:
                    System.out.println("Try another one");
                    break;
                case 1:
                    CreateFunction.input();
                    Function2.input();
                    break;
                case 2:
                    System.out.print("Input fullname to search: ");
                    sc = new Scanner(System.in);
                    String searchFullname = sc.nextLine();
                    boolean s = CreateFunction.searchByFullName(searchFullname.toLowerCase());
                    if(!s){
                    	System.out.println("Not found!");
                    	
                    }else{
                    	CreateFunction.output();
                    }
                    System.out.println("Search by " + searchFullname + " no result");
                    break;
                case 3:
                    System.out.print("Input department to search: ");
                    String searchDepartment = sc.nextLine();

                    boolean sear = CreateFunction.searchByDepartment(searchDepartment);
                    if (!sear) {
                        System.out.println("Search by " + searchDepartment + " no result");
                    }else{
                    	CreateFunction.output();
                    }

                    break;
                case 4:
                	//sort and print
                	
                	 CreateFunction.output();
                     Function2.output();
                	break;
                case 5:
                    break;
                default:
                    System.out.println("Please choose menu [1,2,3,4,5]");
                    break;
            }
        } while (menu != 0);
        
        
    }

}
