import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class GiangVien extends CanBo {

	public GiangVien() {
		// TODO Auto-generated constructor stub
	}

	private String khoa;
	private int tietDay;
	
	public void input(){
		super.input();
		sc.nextLine();
		System.out.print("Khoa: " );
		khoa = sc.nextLine();
		System.out.print("So Tiet Day Trong Thang: ");
		tietDay = sc.nextInt();
	}
	
	public void output(){
		super.output();
		System.out.println("Khoa: " + khoa);
		System.out.println("So tiet day trong thang: " + tietDay);
		System.out.println("Luong thang: " + getsalary() );
		
		        //write into file
				BufferedWriter outp = null;
				try  
				{
				    FileWriter fstream = new FileWriter("myfile.txt", true); 
				    outp = new BufferedWriter(fstream);
				    outp.append("Ho ten: " + names);
				    outp.append("\n");
				    outp.append("Levels: " + trinhDo);
				    outp.append("\n");
				    outp.append("Phu Cap: " + phuCap);
				    outp.append("\n");
				    outp.append("Khoa: " + khoa + "\n");
				    outp.append("\n");
				    outp.append("So tiet day trong thang: " + tietDay);
				    outp.append("\n");
				    outp.append("Luong thang: " + getsalary());
				    outp.append("\n");
				}
				catch (IOException e)
				{
				    System.err.println("Error: " + e.getMessage());
				}
				finally
				{
				    if(outp != null) {
				        try {
							outp.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				    }
				}
	}
	
	
	public String getkhoa(){
		return khoa;
	}
	public void setkhoa(String khoa){
		this.khoa = khoa;
		
	}
	
	@Override
	int getsalary() {
		// TODO Auto-generated method stub
		int salary = getheso() * 730 + getphuCap() + tietDay * 45;
		return salary;
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}


}
